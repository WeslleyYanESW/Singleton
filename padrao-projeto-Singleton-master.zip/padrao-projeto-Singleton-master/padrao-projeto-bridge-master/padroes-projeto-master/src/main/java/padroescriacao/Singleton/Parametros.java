package padroescriacao.singleton;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ParametrosTest {

    @Test
    public void deveRetornarNomeEmpresa() {
        Parametros.getInstance().setNomeEscola("Empresa 1");
        assertEquals("Empresa 1", Parametros.getInstance().getNomeEmpresa());
    }

    @Test
    public void deveRetornarNomeEmpregado() {
        Parametros.getInstance().setUsuarioLogado("Empregado 1");
        assertEquals("Empregado 1", Parametros.getInstance().getNomeEmpregado());
    }

}